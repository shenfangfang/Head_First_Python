from distutils.core import setup
setup(
	name='nester',
	version='1.0.0',
	py_modules=['nester'],
	author='ff',
	author_email='ff.163.com',
	url='http://www.ff.com',
	description='A test from ff'
)